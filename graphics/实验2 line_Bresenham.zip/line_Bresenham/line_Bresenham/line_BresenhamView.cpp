﻿
// line_BresenhamView.cpp: ClineBresenhamView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "line_Bresenham.h"
#endif

#include "line_BresenhamDoc.h"
#include "line_BresenhamView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ClineBresenhamView

IMPLEMENT_DYNCREATE(ClineBresenhamView, CView)

BEGIN_MESSAGE_MAP(ClineBresenhamView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &ClineBresenhamView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()

// ClineBresenhamView 构造/析构

ClineBresenhamView::ClineBresenhamView() noexcept
{
	// TODO: 在此处添加构造代码

}

ClineBresenhamView::~ClineBresenhamView()
{
}

BOOL ClineBresenhamView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// ClineBresenhamView 绘图

void ClineBresenhamView::OnDraw(CDC* /*pDC*/)
{
	ClineBresenhamDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 在此处为本机数据添加绘制代码
}


// ClineBresenhamView 打印


void ClineBresenhamView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL ClineBresenhamView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void ClineBresenhamView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void ClineBresenhamView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}

void ClineBresenhamView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void ClineBresenhamView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// ClineBresenhamView 诊断

#ifdef _DEBUG
void ClineBresenhamView::AssertValid() const
{
	CView::AssertValid();
}

void ClineBresenhamView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

ClineBresenhamDoc* ClineBresenhamView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(ClineBresenhamDoc)));
	return (ClineBresenhamDoc*)m_pDocument;
}
#endif //_DEBUG


// ClineBresenhamView 消息处理程序


//当左键鼠标按钮按下时，记录直线起点位置
void ClineBresenhamView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	this->line.setStartPoint(point);
	CView::OnLButtonDown(nFlags, point);
}

//当左键鼠标按钮松开时，记录直线终点位置并绘制直线
void ClineBresenhamView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	this->line.setEndPoint(point);
	CDC* pDC = GetDC();
	this->line.moveTo(pDC);
	this->line.lineTo(pDC);
	CView::OnLButtonUp(nFlags, point);
}


//当鼠标移动时，在窗口用户区显示鼠标的x坐标和y坐标
void ClineBresenhamView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	CString stringX, stringY;
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMFCStatusBar* pStatus = &pFrame->m_wndStatusBar;
	if (pStatus != NULL)
	{
		//_T是一个宏，作用是让你的程序支持Unicode编码(双字节编码)
		stringX.Format(_T("x=%d"), point.x);
		stringY.Format(_T("y=%d"), point.y);

		CClientDC dc(this);
		CSize sizeX = dc.GetTextExtent(stringX);
		CSize sizeY = dc.GetTextExtent(stringY);
		pStatus->SetPaneInfo(1, nFlags, SBPS_NORMAL, sizeX.cx);
		pStatus->SetPaneText(1, stringX);
		pStatus->SetPaneInfo(2, nFlags, SBPS_NORMAL, sizeY.cx);
		pStatus->SetPaneText(2, stringY);
	}

	CView::OnMouseMove(nFlags, point);
}
