﻿
// line_BresenhamView.h: ClineBresenhamView 类的接口
//

#pragma once
#include "CLine.h"

class ClineBresenhamView : public CView
{
protected: // 仅从序列化创建
	ClineBresenhamView() noexcept;
	DECLARE_DYNCREATE(ClineBresenhamView)

// 特性
public:
	ClineBresenhamDoc* GetDocument() const;

// 操作
public:

// 重写
public:
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 实现
public:
	virtual ~ClineBresenhamView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	//当鼠标左键按下时，记录直线起点位置
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//当鼠标左键按钮松开时，记录直线终点位置并绘制直线
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//当鼠标移动时，在窗口用户区显示鼠标的x坐标和y坐标
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
private:
	//直线类
	CLine line;
};

#ifndef _DEBUG  // line_BresenhamView.cpp 中的调试版本
inline ClineBresenhamDoc* ClineBresenhamView::GetDocument() const
   { return reinterpret_cast<ClineBresenhamDoc*>(m_pDocument); }
#endif

