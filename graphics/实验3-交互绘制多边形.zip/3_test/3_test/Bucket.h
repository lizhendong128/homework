#pragma once
#include"AET.h"
class Bucket
{
public:
	int ScanLine;
	AET* p;
	Bucket* next;
};

