﻿
// 3_testView.cpp: CMy3testView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "3_test.h"
#endif
#define ROUND(a) int(a+0.5)//四舍五入

int isPress = 0; 
int Number = 0; // 记录点的个数
int draw = 0; // 标志是否绘制完、
CPoint start; 
CPoint end;
CPoint first;

#include "3_testDoc.h"
#include "3_testView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy3testView

IMPLEMENT_DYNCREATE(CMy3testView, CView)

BEGIN_MESSAGE_MAP(CMy3testView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMy3testView::OnFilePrintPreview)
//	ON_WM_CONTEXTMENU()
//	ON_WM_RBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
//	ON_WM_LBUTTONUP()
//	ON_WM_TIMER()
ON_WM_RBUTTONDOWN()
END_MESSAGE_MAP()

// CMy3testView 构造/析构

CMy3testView::CMy3testView() noexcept
{
	// TODO: 在此处添加构造代码

}

CMy3testView::~CMy3testView()
{
}

BOOL CMy3testView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CMy3testView 绘图

void CMy3testView::OnDraw(CDC* /*pDC*/)
{
	CMy3testDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 在此处为本机数据添加绘制代码
}


// CMy3testView 打印


void CMy3testView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMy3testView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CMy3testView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CMy3testView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}

//void CMy3testView::OnRButtonUp(UINT /* nFlags */, CPoint point)
//{
//	ClientToScreen(&point);
//	OnContextMenu(this, point);
//}

//void CMy3testView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
//{
//#ifndef SHARED_HANDLERS
//	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
//#endif
//}


// CMy3testView 诊断

#ifdef _DEBUG
void CMy3testView::AssertValid() const
{
	CView::AssertValid();
}

void CMy3testView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy3testDoc* CMy3testView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy3testDoc)));
	return (CMy3testDoc*)m_pDocument;
}
#endif //_DEBUG


// CMy3testView 消息处理程序
void CMy3testView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	if (isPress == 1 || Number == 0)
	{
		isPress = 1; //判断按下
		start = point;
		end = start;
		Point[Number] = start;//保存点
		if (Number == 0)
			first = start;//保存起点
		Number++;//add the num
	}
	CView::OnLButtonDown(nFlags, point);
}


void CMy3testView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	CDC* pDC = this->GetWindowDC();
	if (isPress)
	{
		pDC->SetROP2(R2_NOT);
		pDC->MoveTo(start);
		pDC->LineTo(end);
		if ((point.x - first.x) < 0.1 && (point.y - first.y) < 0.1)//如果回到起点，绘图完毕，停止
		{
			point = first;
			isPress = 0;
		}
		pDC->MoveTo(start);
		pDC->LineTo(point);
		end = point;
	}
	CView::OnMouseMove(nFlags, point);
}


void CMy3testView::CreatBucket()//建立桶结点
{
	int ScanMin, ScanMax;//确定扫描线的最小值和最大值
	ScanMax = ScanMin = Point[0].y;
	for (int i = 1; i < Number; i++)
	{
		if (Point[i].y < ScanMin)
		{
			ScanMin = Point[i].y;//扫描线的最小值			
		}
		if (Point[i].y > ScanMax)
		{
			ScanMax = Point[i].y;//扫描线的最大值
		}
	}
	for (int i = ScanMin; i <= ScanMax; i++)//建立桶结点
	{
		if (ScanMin == i)//桶头结点
		{
			HeadB = new Bucket;//建立桶的头结点
			CurrentB = HeadB;//CurrentB为Bucket当前结点指针
			CurrentB->ScanLine = ScanMin;
			CurrentB->p = NULL;//没有连接边链表
			CurrentB->next = NULL;
		}
		else//建立桶的其它结点
		{
			CurrentB->next = new Bucket;//新建一个桶结点
			CurrentB = CurrentB->next;//使CurrentB指向新建的桶结点
			CurrentB->ScanLine = i;
			CurrentB->p = NULL;//没有连接边链表
			CurrentB->next = NULL;
		}
	}
}


void CMy3testView::Et()//构造边表
{
	for (int i = 0; i < Number; i++)//访问每个顶点
	{
		CurrentB = HeadB;//从桶链表的头结点开始循环
		int j = i + 1;//边的第二个顶点，Point[i]和Point[j]构成边
		if (j == Number) j = 0;//保证多边形的闭合
		if (Point[j].y > Point[i].y)//终点比起点高
		{
			while (CurrentB->ScanLine != Point[i].y)//在桶内寻找该边的yMin
			{
				CurrentB = CurrentB->next;//移到下一个桶结点
			}
			E[i].x = Point[i].x;//计算AET表的值
			E[i].yMax = Point[j].y;
			E[i].k = double((Point[j].x - Point[i].x)) / (Point[j].y - Point[i].y);//代表1/k			
			E[i].next = NULL;
			CurrentE = CurrentB->p;//获得桶上链接边表的地址
			if (CurrentB->p == NULL)//当前桶结点上没有链接边结点
			{
				CurrentE = &E[i];//赋边的起始地址
				CurrentB->p = CurrentE;//第一个边结点直接连接到对应的桶中
			}
			else
			{
				while (CurrentE->next != NULL)//如果当前边已连有边结点
				{
					CurrentE = CurrentE->next;//移动指针到当前边的最后一个边结点					
				}
				CurrentE->next = &E[i];//把当前边接上去
			}
		}
		if (Point[j].y < Point[i].y)//终点比起点低
		{
			while (CurrentB->ScanLine != Point[j].y)
			{
				CurrentB = CurrentB->next;
			}
			E[i].x = Point[j].x;
			E[i].yMax = Point[i].y;
			E[i].k = double((Point[i].x - Point[j].x)) / (Point[i].y - Point[j].y);
			E[i].next = NULL;
			CurrentE = CurrentB->p;
			if (CurrentE == NULL)
			{
				CurrentE = &E[i];
				CurrentB->p = CurrentE;
			}
			else
			{
				while (CurrentE->next != NULL)
				{
					CurrentE = CurrentE->next;
				}
				CurrentE->next = &E[i];
			}
		}
	}
	CurrentB = NULL;
	CurrentE = NULL;
}


void CMy3testView::AddEdge(AET* NewEdge)//插入临时边表
{
	T1 = HeadE;
	if (T1 == NULL)//边表为空,将边表置为TempEdge
	{
		T1 = NewEdge;
		HeadE = T1;
	}
	else
	{
		while (T1->next != NULL)//边表不为空,将TempEdge连在该边之后
		{
			T1 = T1->next;
		}
		T1->next = NewEdge;
	}
}


void CMy3testView::EdgeOrder()//对边表进行排序
{
	T1 = HeadE;
	if (T1 == NULL)
	{
		return;
	}
	if (T1->next == NULL)//如果该边表没有再连边表
	{
		return;//桶结点只有一条边，不需要排序
	}
	else
	{
		if (T1->next->x < T1->x)//边表按x值排序
		{
			T2 = T1->next;
			T1->next = T2->next;
			T2->next = T1;
			HeadE = T2;
		}
		T2 = HeadE;
		T1 = HeadE->next;
		while (T1->next != NULL)//继续两两比较相连的边表的x值,进行排序
		{
			if (T1->next->x < T1->x)
			{
				T2->next = T1->next;
				T1->next = T1->next->next;
				T2->next->next = T1;
				T2 = T2->next;
			}
			else
			{
				T2 = T1;
				T1 = T1->next;
			}
		}
	}
}


void CMy3testView::PolygonFill()//多边形填充
{
	HeadE = NULL;
	for (CurrentB = HeadB; CurrentB != NULL; CurrentB = CurrentB->next)//访问所有桶结点
	{
		for (CurrentE = CurrentB->p; CurrentE != NULL; CurrentE = CurrentE->next)//访问桶中排序前的边结点			
		{
			AET* TempEdge = new AET;
			TempEdge->x = CurrentE->x;
			TempEdge->yMax = CurrentE->yMax;
			TempEdge->k = CurrentE->k;
			TempEdge->next = NULL;
			AddEdge(TempEdge);//将该边插入临时Aet表
		}
		EdgeOrder();//使得边表按照x递增的顺序存放		
		T1 = HeadE;//根据ymax抛弃扫描完的边结点
		if (T1 == NULL)
		{
			return;
		}
		while (CurrentB->ScanLine >= T1->yMax)//放弃该结点，Aet表指针后移（下闭上开）
		{
			T1 = T1->next;
			HeadE = T1;
			if (HeadE == NULL)
			{
				return;
			}
		}
		if (T1->next != NULL)
		{
			T2 = T1;
			T1 = T2->next;
		}
		while (T1 != NULL)
		{
			if (CurrentB->ScanLine >= T1->yMax)//跳过一个结点
			{
				T2->next = T1->next;
				T1->next = NULL;
				T1 = T2->next;
			}
			else
			{
				T2 = T1;
				T1 = T2->next;
			}
		}
		BOOL In = false;//设置一个BOOL变量In，初始值为假
		double xb, xe;//扫描线的起点和终点
		for (T1 = HeadE; T1 != NULL; T1 = T1->next)//填充扫描线和多边形相交的区间
		{
			if (In == false)
			{
				xb = T1->x;
				In = true;//每访问一个结点,把In值取反一次
			}
			else//如果In值为真，则填充从当前结点的x值开始到下一结点的x值结束的区间
			{
				xe = T1->x - 1;//左闭右开
				CClientDC dc(this);
				for (double x = xb; x <= xe; x++)
					dc.SetPixel(ROUND(x), CurrentB->ScanLine, GetColor);//填充语句
				//Sleep(1);//延时1ms,提高填充过程的可视性
				In = FALSE;
			}
		}
		for (T1 = HeadE; T1 != NULL; T1 = T1->next)//边连贯性
		{
			T1->x = T1->x + T1->k;//x=x+1/k				 
		}
	}
	delete HeadB;
	delete CurrentB;
	delete CurrentE;
	delete HeadE;
}


void CMy3testView::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	// 按下右键，程序绘制
	if (isPress == 0 && Number > 0 && draw == 0)
	{
		RedrawWindow();//刷新屏幕
		CreatBucket();//初始化桶
		Et();//用于建立边表	
		PolygonFill();//多边形填充	
		draw = 1;
	}
	
	CView::OnRButtonDown(nFlags, point);
}
