﻿
// 3_testView.h: CMy3testView 类的接口
//

#pragma once

#include "AET.h"//包含有效边表类
#include "Bucket.h"//包含桶类




class CMy3testView : public CView
{
protected: // 仅从序列化创建
	CMy3testView() noexcept;
	DECLARE_DYNCREATE(CMy3testView)

// 特性
public:
	CMy3testDoc* GetDocument() const;

// 操作
public:
	void PolygonFill();//上闭下开填充多边形
	void CreatBucket();//建立桶结点桶
	void Et();//构造边表
	void AddEdge(AET*);//将边插入AET表
	void EdgeOrder();//对AET表进行排序
// 重写
public:
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 实现
public:
	virtual ~CMy3testView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	COLORREF GetColor;//调色板
	CPoint Point[100];//定义多边形
	Bucket* HeadB, * CurrentB;//桶的头结点和当前结点
	AET E[100], * HeadE, * CurrentE, * T1, * T2;//有效边表的结点

// 生成的消息映射函数
protected:
	afx_msg void OnFilePrintPreview();
//	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
//	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
//	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
//	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
};

#ifndef _DEBUG  // 3_testView.cpp 中的调试版本
inline CMy3testDoc* CMy3testView::GetDocument() const
   { return reinterpret_cast<CMy3testDoc*>(m_pDocument); }
#endif

