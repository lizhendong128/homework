#pragma once
class AET
{
public:
	double x;
	int yMax;
	double k;
	AET* next;
};

